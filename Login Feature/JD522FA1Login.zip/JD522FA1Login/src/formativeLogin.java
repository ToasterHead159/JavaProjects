
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.ArrayList;

public class formativeLogin {

    private String Username;
    private String Password;
    private String FirstName;
    private String LastName;

    public formativeLogin(String Username, String Password, String FirstName, String LastName) {
        this.Username = Username;
        this.Password = Password;
        this.FirstName = FirstName;
        this.LastName = LastName;
    }
    //these are getters and setters for the formativeLogin object
    public String getUsername() {
        return Username;
    }

    public void setUsername(String Username) {
        this.Username = Username;
    }

    public String getPassword() {
        return Password;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getFirstname() {
        return FirstName;
    }

    public void setFirstname(String Firstname) {
        this.FirstName = Firstname;
    }

    public String getLastname() {
        return LastName;
    }

    public void setLasrname(String Lastname) {
        this.LastName = Lastname;
    }
    //method used to check if the username meets the requirements
    public static boolean correctUserName(String Username) {

        return Username.contains("#") && Username.length() < 8;
    }
    //this is to check if the user can be registered or not.
    public static ArrayList regUser(boolean checkedUser, boolean Passcheck, boolean checkFirst, boolean checkLast){
        ArrayList list = new ArrayList();
        if (checkedUser == true && Passcheck == true && checkFirst == true && checkLast == true){
            boolean validUser = true;
            list.add(validUser);
            String message = "<HTML>Username Accepted, Proceed<BR>Password Accepted<BR>Registration successful!";
            list.add(message);
            return list;
        } else if (checkedUser == false){
            boolean validUser = false;
            list.add(validUser);
            String message = "<HTML>Username does not meet the criteria, <BR>please ensure that your username contains an pound sign <BR>and is no more than 8 characters in length.";
            list.add(message);
            return list;
        } else if (Passcheck == false){
            boolean validUser = false;
            list.add(validUser);
            String message = "Password not Accepted, please check that you have met all the criteria required.";
            list.add(message);
            return list;
        } else if (checkFirst == false){
            boolean validUser = false;
            list.add(validUser);
            String message = "First Name cannot be empty!";
            list.add(message);
            return list;
        } else if (checkLast == false){
            boolean validUser = false;
            list.add(validUser);
            String message = "Last Name cannot be empty!";
            list.add(message);
        } else {
            boolean validUser = false;
            list.add(validUser);
            String message = "Registration failed";
            list.add(message);
            return list;
        }
            boolean validUser = false;
            list.add(validUser);
            String message = "Registration failed";
            list.add(message);
            return list;
    }
    //this is used to check if the password requirements are met.
    public static boolean meetPasswordComplexity(String regPass) {
        Pattern pat = Pattern.compile("^(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$");
        Matcher mat = pat.matcher(regPass);
        boolean passCorrect = mat.find();
        return passCorrect == true;
    }
    //checks if the firstName is not empty
    public static boolean firstNotempty(String FirstName) {
        return !FirstName.isEmpty();
    }
    //checks if the last Name is not empty
    public static boolean lastNotempty(String LastName) {
        return !LastName.isEmpty();
    }
    //Here is where the checking if the login details are checked if they are accurate.
    public static String login(ArrayList<formativeLogin> Users, String logUsername, String logPassword) {

        for (formativeLogin user : Users) {
            if (logUsername.equals(user.getUsername())) {
                if (logPassword.equals(user.getPassword())) {
                    String message = returnLogin(user);
                    return message;
                } else {
                    return "Incorrect password, try again";
                }

            } else {

                continue;
            }
        }
        return "Incorrect credentials have been supplied, try again";
    }
    //this method returns the successful message when the user has successfully logged in. 
    public static String returnLogin(formativeLogin user) {
        return "<HTML>Congratulations " + user.FirstName + " " + user.LastName + ", <BR>You have made it to the second year. <BR>Wishing you all the best!!</HTML>";
    }
}

//VH/FH